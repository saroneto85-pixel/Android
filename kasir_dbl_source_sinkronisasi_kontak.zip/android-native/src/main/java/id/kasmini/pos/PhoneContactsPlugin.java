package id.kasmini.pos;

import android.Manifest;
import android.database.Cursor;
import android.provider.ContactsContract;
import com.getcapacitor.*;
import com.getcapacitor.annotation.*;
import org.json.JSONArray;
import org.json.JSONObject;

@CapacitorPlugin(name = "PhoneContacts", permissions = {
    @Permission(alias = "contacts", strings = { Manifest.permission.READ_CONTACTS })
})
public class PhoneContactsPlugin extends Plugin {
    @PluginMethod
    public void getContacts(PluginCall call) {
        if (getPermissionState("contacts") != PermissionState.GRANTED) {
            requestPermissionForAlias("contacts", call, "contactsPermissionCallback");
            return;
        }
        readContacts(call);
    }

    @PermissionCallback
    private void contactsPermissionCallback(PluginCall call) {
        if (getPermissionState("contacts") == PermissionState.GRANTED) {
            readContacts(call);
        } else {
            call.reject("Izin membaca kontak ditolak. Aktifkan izin Kontak untuk Kasir DBL di Pengaturan Android.");
        }
    }

    private void readContacts(PluginCall call) {
        new Thread(() -> {
            JSONArray result = new JSONArray();
            Cursor phones = null;
            try {
                String[] projection = {
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                };
                phones = getContext().getContentResolver().query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    projection, null, null,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC"
                );
                if (phones != null) {
                    java.util.HashSet<String> seen = new java.util.HashSet<>();
                    while (phones.moveToNext()) {
                        String id = phones.getString(0);
                        String name = phones.getString(1);
                        String number = phones.getString(2);
                        if (number == null || number.trim().isEmpty()) continue;
                        String normalized = number.replaceAll("[^0-9+]", "");
                        if (!seen.add(id + "|" + normalized)) continue;
                        String email = "";
                        Cursor emails = null;
                        try {
                            emails = getContext().getContentResolver().query(
                                ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                                new String[]{ContactsContract.CommonDataKinds.Email.ADDRESS},
                                ContactsContract.CommonDataKinds.Email.CONTACT_ID + "=?",
                                new String[]{id}, null
                            );
                            if (emails != null && emails.moveToFirst()) email = emails.getString(0);
                        } finally { if (emails != null) emails.close(); }
                        JSONObject item = new JSONObject();
                        item.put("name", name == null ? "" : name);
                        item.put("phone", number);
                        item.put("email", email == null ? "" : email);
                        result.put(item);
                    }
                }
                JSObject response = new JSObject();
                response.put("contacts", new JSArray(result));
                call.resolve(response);
            } catch (Exception e) {
                call.reject("Gagal membaca kontak HP: " + e.getMessage(), e);
            } finally {
                if (phones != null) phones.close();
            }
        }, "kasir-dbl-contacts").start();
    }
}
