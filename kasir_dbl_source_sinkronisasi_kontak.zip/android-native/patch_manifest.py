from pathlib import Path
p=Path('android/app/src/main/AndroidManifest.xml')
s=p.read_text()
perms='''    <uses-permission android:name="android.permission.READ_CONTACTS" />
    <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
    <uses-permission android:name="android.permission.BLUETOOTH_SCAN" />
'''
for permission in ['android.permission.READ_CONTACTS','android.permission.BLUETOOTH_CONNECT']:
    if permission not in s:
        line = next(x for x in perms.splitlines() if permission in x)
        s=s.replace('<application', line+'\n    <application', 1)
# Add legacy Bluetooth permissions when absent.
for permission in ['android.permission.BLUETOOTH','android.permission.BLUETOOTH_ADMIN','android.permission.BLUETOOTH_SCAN']:
    if permission not in s:
        line = next(x for x in perms.splitlines() if permission in x)
        s=s.replace('<application', line+'\n    <application', 1)
p.write_text(s)
