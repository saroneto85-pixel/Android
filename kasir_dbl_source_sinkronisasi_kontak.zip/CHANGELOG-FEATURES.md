# Perubahan pada paket source ini

1. PIN admin ditingkatkan menjadi enam digit dan diverifikasi dengan SHA-256 + salt.
2. Edit/hapus produk, edit transaksi, laporan, dan pengaturan meminta PIN.
3. Foto produk dapat dipilih dari kamera atau galeri; diperkecil sebelum disimpan di SQLite.
4. Ditambahkan menu pelanggan dengan tambah/edit/hapus, import/update CSV, template dan ekspor.
5. Ditambahkan native bridge Android Bluetooth Classic SPP dan perintah cetak ESC/POS untuk RPP02N.
6. Ditambahkan pembuatan struk PDF dan berbagi melalui Android Share Sheet agar dapat diteruskan ke WhatsApp.
7. Perhitungan keuntungan harian dan laporan yang sudah ada dipertahankan.


## Revisi dashboard dan ikon launcher (17 November 2026)
- Menghapus kartu Keuntungan Hari Ini dari dashboard utama; perhitungan keuntungan dan laporan tetap tersedia pada menu Laporan.
- Memperbaiki workflow agar seluruh resource ikon launcher Bumbu Lengkep (mipmap, adaptive icon, foreground, dan warna latar) disalin ke proyek Android setelah Capacitor sync.


## Sinkronisasi Kontak HP
- Menambahkan tombol **Sinkronkan Kontak HP** pada menu Pelanggan.
- Menggunakan izin Android `READ_CONTACTS` yang diminta hanya ketika pengguna menekan tombol sinkronisasi.
- Membaca nama, nomor telepon, dan email dari kontak lokal; tidak ada sinkronisasi latar belakang atau pengiriman ke server.
- Mencocokkan pelanggan berdasarkan nomor telepon yang dinormalisasi; kontak baru ditambahkan dan pelanggan yang cocok diperbarui.
- Mempertahankan alamat dan catatan pelanggan yang telah tersimpan.
- Kontak tanpa nama atau nomor valid dilewati.
