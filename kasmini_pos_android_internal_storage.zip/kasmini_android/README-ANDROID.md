# Kasmini POS Android (Capacitor + SQLite)

Proyek ini mengemas antarmuka Kasmini POS revisi ke aplikasi Android menggunakan Capacitor. Pada Android, data memakai SQLite lokal melalui `@capacitor-community/sqlite`. Database disimpan di direktori privat aplikasi Android (`data/data/<applicationId>/databases`), sehingga data berada di memori internal HP, tidak memerlukan internet, dan tidak dapat dibaca aplikasi lain secara normal. Ketika dibuka sebagai web biasa, aplikasi tetap memakai IndexedDB browser.

## Kebutuhan build
- Node.js 20 atau lebih baru dan npm
- Android Studio dengan Android SDK (platform + build-tools)
- JDK 17 (gunakan JDK yang direkomendasikan versi Android Gradle Plugin yang dipasang)
- Koneksi internet saat pertama memasang dependensi Gradle/npm

## Build pertama
```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```
Di Android Studio, tunggu Gradle sync selesai, lalu pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**. APK debug biasanya berada di `android/app/build/outputs/apk/debug/app-debug.apk`.

## Perubahan teknis
- SQLite menyimpan empat kelompok data: products, transactions, expenses, settings. Di Android, SQLite merupakan penyimpanan utama; aplikasi tidak memakai IndexedDB sebagai fallback jika SQLite gagal dibuka.
- Backup JSON mencakup seluruh empat kelompok tersebut; restore menggabungkan record berdasarkan ID (tidak menghapus record yang tidak ada di backup). Validasi struktur dan ID dilakukan sebelum proses pemulihan.
- Excel tetap diekspor sebagai `.xlsx`.
- Mode browser/PWA tetap memakai IndexedDB sebagai fallback.

## Penting tentang data lama
Data IndexedDB yang ada di browser tidak otomatis dipindahkan ke SQLite Android. Sebelum beralih, buka PWA lama dan gunakan **Cadangkan data (JSON)**. Setelah APK terpasang, buka aplikasi lalu gunakan **Pulihkan cadangan JSON**. Simpan file backup di lokasi aman. Perlu diketahui: menghapus aplikasi atau memilih Hapus Data aplikasi Android akan menghapus database internal; lakukan backup terlebih dahulu.

## Status
Source proyek dan adapter SQLite disiapkan. APK belum dibangun atau diuji karena membutuhkan Android SDK/Android Studio dan Gradle pada mesin build.


## Penyimpanan internal HP

Pada perangkat Android, database `kasmini_pos` dikelola oleh plugin SQLite dan disimpan pada area database privat aplikasi di memori internal. Data produk, transaksi, pengeluaran, dan pengaturan tetap tersimpan setelah aplikasi ditutup atau HP dinyalakan ulang. Data tidak disinkronkan ke cloud/server. Pengguna aplikasi lain tidak dapat mengakses file database melalui pengelola file biasa. Gunakan fitur Cadangkan data (JSON) untuk membuat salinan yang dapat dipindahkan.

## Build otomatis melalui GitHub Actions

Workflow `.github/workflows/build-android.yml` akan:
1. Memasang dependency Node.js dan menyiapkan JDK 17 serta Android SDK.
2. Menjalankan build Vite.
3. Membuat project native Android dengan `npx cap add android`.
4. Menyinkronkan plugin Capacitor.
5. Menjalankan Gradle `assembleDebug`.
6. Mengunggah `app-debug.apk` sebagai artifact bernama `kasmini-pos-debug-apk`.

Untuk mengaktifkannya, unggah isi folder proyek ini ke repository GitHub pada branch `main` atau `master`, lalu buka tab **Actions** dan jalankan workflow **Build Android APK** melalui **Run workflow**. Setelah status workflow berhasil, buka hasil run dan unduh artifact `kasmini-pos-debug-apk`.

Catatan: ZIP sumber ini tidak menyertakan folder `android/`; workflow memang membuat project native tersebut pada runner GitHub. APK yang dihasilkan adalah APK debug untuk pengujian, bukan APK release bertanda tangan untuk distribusi Play Store.
