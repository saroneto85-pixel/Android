# POS Kasmini+ — PWA offline

Aplikasi kasir PWA untuk Android/HP/tablet. Semua data disimpan lokal menggunakan IndexedDB.

## Menjalankan
PWA membutuhkan HTTPS atau localhost agar Service Worker dan instalasi bekerja.
1. Ekstrak ZIP ke hosting statis yang mendukung HTTPS (mis. hosting web sendiri).
2. Buka URL aplikasi di Chrome Android.
3. Pilih **Pasang** atau menu Chrome → **Tambahkan ke layar utama**.
4. Buka sekali saat online agar aset tersimpan untuk penggunaan offline.

Untuk uji coba komputer: jalankan server lokal dari folder ini, misalnya `python -m http.server 8000`, lalu buka `http://localhost:8000`.

## Fitur
- Dashboard ringkasan penjualan hari ini.
- Produk, kategori, SKU, HPP, harga jual, stok opsional, dan logo toko PNG.
- Transaksi Dine In, Delivery, Take Away.
- Pembayaran tunai, QRIS, transfer, kartu debit/kredit, e-wallet, tempo/kasbon.
- Riwayat transaksi dan detail/struk.
- Laporan harian, mingguan, bulanan, tahunan, rentang tanggal.
- Rekap per produk, kategori, kasir, tipe transaksi, metode pembayaran.
- Ekspor workbook Excel asli (.xlsx) dengan rincian item, HPP, harga jual, tipe transaksi, metode pembayaran, dan laba kotor per item.
- Pencatatan pengeluaran.
- Profil toko, backup/restore JSON, cetak melalui dialog browser.
- Service Worker untuk cache aset offline.

## Catatan penting
- Data hanya ada pada browser/perangkat yang digunakan. Tidak ada sinkronisasi cloud, multi-device, login, atau server.
- Lakukan backup JSON secara rutin. Menghapus data situs/browser dapat menghapus database.
- Printer Bluetooth dan cetak langsung bergantung pada dukungan Android/browser/printer; saat ini tombol cetak membuka dialog cetak browser.
- Stok disimpan pada data produk, tetapi pengurangan stok otomatis dan stok opname belum diaktifkan pada versi awal ini.
- File .xls menggunakan format Spreadsheet XML yang dapat dibuka oleh Microsoft Excel dan aplikasi spreadsheet kompatibel.
- Ini adalah prototipe fungsional awal. Uji data dan alur operasional sebelum dipakai untuk pencatatan usaha produksi.


## Pembaruan revisi
- Menambahkan input HPP pada form produk; HPP dan SKU disalin sebagai snapshot saat transaksi dibuat.
- Ekspor laporan memakai format Office Open XML `.xlsx` yang dapat dibuka di Excel dan aplikasi spreadsheet kompatibel.
- Menambahkan unggah logo toko PNG (maksimal 2 MB) beserta pratinjau; logo disimpan bersama pengaturan lokal.
- Mengubah tema aplikasi menjadi hijau dan kuning.
