# KASIR DBL merged project

Project source is based on the uploaded UX-refined source ZIP. The second uploaded ZIP contained only `app-debug.apk`, not source files; it is included in `reference-apk/` as a reference build and cannot be reverse-merged into source code.

Included source-level changes:
- Retained source UI styling and UX-refined stylesheet.
- Updated Android Actions SDK setup to v4.
- Added Gradle init-script Maven mirror fallback to workflow.
- Workflow builds a fresh APK from this project source.

The included reference APK is not the APK produced by this project build. Build validation is not claimed.
