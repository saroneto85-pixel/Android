# KASIR DBL source revision
- Refreshed green/yellow UI styling, mobile navigation, header safe-area and prominence of central transaction action.
- Updated Android SDK setup workflow to v4.
- Added Maven mirror fallback init script to the Gradle build job.
- Source features/schema remain based on 1.2.0; this revision does not claim new feature implementation or device validation.
