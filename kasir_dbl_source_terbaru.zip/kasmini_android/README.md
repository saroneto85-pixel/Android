# Kasir DBL

Source code aplikasi kasir offline untuk Android dan browser. Untuk petunjuk build, penyimpanan data, fitur yang tersedia, dan batasan implementasi, baca [README-ANDROID.md](README-ANDROID.md).
