# Perubahan pada paket source ini

1. PIN admin ditingkatkan menjadi enam digit dan diverifikasi dengan SHA-256 + salt.
2. Edit/hapus produk, edit transaksi, laporan, dan pengaturan meminta PIN.
3. Foto produk dapat dipilih dari kamera atau galeri; diperkecil sebelum disimpan di SQLite.
4. Ditambahkan menu pelanggan dengan tambah/edit/hapus, import/update CSV, template dan ekspor.
5. Ditambahkan native bridge Android Bluetooth Classic SPP dan perintah cetak ESC/POS untuk RPP02N.
6. Ditambahkan pembuatan struk PDF dan berbagi melalui Android Share Sheet agar dapat diteruskan ke WhatsApp.
7. Perhitungan keuntungan harian dan laporan yang sudah ada dipertahankan.
